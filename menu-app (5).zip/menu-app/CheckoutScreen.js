import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, Button, Alert } from 'react-native';

const CheckoutScreen = ({ selectedItems, onNavigate }) => {
  const [isCheckedOut, setIsCheckedOut] = useState(false);
  const total = selectedItems.reduce((sum, item) => sum + item.price, 0);

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.itemName}>{item.name}</Text>
      <Text style={styles.itemPrice}>{`R${item.price.toFixed(2)}`}</Text>
    </View>
  );

  const handleCheckout = () => {
    setIsCheckedOut(true);
  };

  if (isCheckedOut) {
    return (
      <View style={styles.container}>
        <Text style={styles.thankYouText}>Thank you for choosing Christopher's Cullinery!</Text>
        <Button title="Rate Us" onPress={() => onNavigate('Rating')} color="#841584" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={selectedItems}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
      />
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>Total:</Text>
        <Text style={styles.totalAmount}>{`R${total.toFixed(2)}`}</Text>
      </View>
      <Button title="Checkout" onPress={handleCheckout} color="#841584" />
      <Button title="Back to Menu" onPress={() => onNavigate('Menu')} color="#841584" />
      <Button title="Profile" onPress={() => onNavigate('Profile')} color="#841584" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 10,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  itemPrice: {
    fontSize: 14,
    color: 'gray',
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    padding: 10,
    borderTopWidth: 1,
    borderColor: 'gray',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalAmount: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  thankYouText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
});

export default CheckoutScreen;

