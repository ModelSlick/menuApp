import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, FlatList, Image } from 'react-native';
import colors from './coloures/colors'; 

const EnterMenuScreen = ({ onNavigate, onMenuUpdate }) => {
  const [menu, setMenu] = useState([]);
  const [mealType, setMealType] = useState('');
  const [course, setCourse] = useState('');
  const [mealName, setMealName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');

  const handleAddMeal = () => {
    const newMenu = [...menu, { id: Date.now().toString(), type: mealType, course: course, name: mealName, description: description, price: price }];
    setMenu(newMenu);
    onMenuUpdate(newMenu);
    setMealType('');
    setCourse('');
    setMealName('');
    setDescription('');
    setPrice('');
  };

  const renderMenuItem = ({ item }) => (
    <View style={styles.menuItem}>
      <Text style={styles.menuText}>{item.course} - {item.type}: {item.name} - R{item.price}</Text>
      <Text style={styles.descriptionText}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Image source={require('./assets/christofell.jpg')} style={styles.logo} />
      <Text style={styles.title}>whats on the menu today</Text>
      <TextInput
        style={styles.input}
        placeholder="Meal Type (Vegan/Non-Vegan)"
        value={mealType}
        onChangeText={setMealType}
      />
      <TextInput
        style={styles.input}
        placeholder="Course (Starter/Main Course/Dessert)"
        value={course}
        onChangeText={setCourse}
      />
      <TextInput
        style={styles.input}
        placeholder="Meal Name"
        value={mealName}
        onChangeText={setMealName}
      />
      <TextInput
        style={styles.input}
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
      />
      <TextInput
        style={styles.input}
        placeholder="Price"
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
      />
      <Button title="Add Meal" onPress={handleAddMeal} color={colors.primary} />
      <FlatList
        data={menu}
        renderItem={renderMenuItem}
        keyExtractor={(item) => item.id}
      />
      <Button title="Save Menu" onPress={() => onNavigate('Menu')} color={colors.primary} />
      <Button title="Back" onPress={() => onNavigate('Home')} color={colors.primary} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.background,
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'YourCustomFont', // Replace with your font name
    color: colors.text, // Replace with your color variable
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
    width: '80%',
  },
  menuItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  menuText: {
    fontSize: 18,
  },
  descriptionText: {
    fontSize: 14,
    color: 'gray',
  },
});

export default EnterMenuScreen;
