import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Image, Alert } from 'react-native';
import colors from './coloures/colors'; 

const LoginScreen = ({ onNavigate }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (username === '' || password === '') {
      Alert.alert('Error', 'Hey stranger, please verify yourself for access');
    } else {
      onNavigate('Home');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.topRightText}>from lihle, smile life is just as tasty</Text>
      <Image source={require('./assets/christofell.jpg')} style={styles.image} />
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="LOGIN" onPress={handleLogin} color={colors.primary} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.background,
  },
  topRightText: {
    position: 'absolute',
    top: 10,
    right: 10,
    fontSize: 12,
    color: colors.primary,
    fontFamily: 'YourCustomFont', // Replace with your font name
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'YourCustomFont', // Replace with your font name
    color: colors.primary,
    marginBottom: 16,
  },
  input: {
    width: '100%',
    padding: 8,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: colors.secondary,
    borderRadius: 4,
    fontFamily: 'YourCustomFont', // Replace with your font name
  },
});

export default LoginScreen;
