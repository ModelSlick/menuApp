// colors.js
export default {
  primary: '#3498db', // Blue
  secondary: '#2ecc71', // Green
  background: '#ecf0f1', // Light gray
  text: '#2c3e50', // Dark gray
  accent: '#e74c3c', // Red
  // Add more colors as needed
};
