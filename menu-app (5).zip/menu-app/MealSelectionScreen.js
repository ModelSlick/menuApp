// screens/MenuScreen.js
import React from 'react';
import { View, Text, Button, FlatList, Image, StyleSheet } from 'react-native';
import colors from './coloures/colors'; // Corrected path

const MenuScreen = ({ route, navigation }) => {
  const meal = route.params?.meal;
  const menu = [
    { id: 1, course: 'Starter', type: 'Vegan', name: 'Salad', price: 50, image: 'https://example.com/salad.jpg', vegan: true },
    { id: 2, course: 'Main', type: 'Non-Vegan', name: 'Steak', price: 150, image: 'https://example.com/steak.jpg', vegan: false },
    { id: 3, course: 'Dessert', type: 'Vegan', name: 'Fruit Salad', price: 70, image: 'https://example.com/fruit-salad.jpg', vegan: true },
    // Add more items as needed
  ];

  if (meal) {
    menu.push({ id: menu.length + 1, course: 'Custom', type: 'Custom', name: meal.name, price: meal.price, image: 'https://example.com/custom.jpg', vegan: false });
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={require('./assets/christofell.jpg')} style={styles.logo} />
        <Text style={styles.title}>Today's Menu</Text>
      </View>
      <FlatList
        data={menu}
        renderItem={({ item }) => (
          <View style={styles.menuItemContainer}>
            <Text style={styles.menuItem}>{item.course} - {item.type}: {item.name} - R{item.price}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id.toString()}
      />
      <View style={styles.buttonContainer}>
        <Button title="Next" onPress={() => navigation.navigate('Checkout', { selectedMeal: menu[0] })} color={colors.primary} />
        <Button title="Back" onPress={() => navigation.goBack()} color={colors.primary} />
        <Button title="Vegan" onPress={() => navigation.navigate('Vegan')} color={colors.primary} />
        <Button title="Non-Vegan" onPress={() => navigation.navigate('NonVegan')} color={colors.primary} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f9f9f9', // Changed to a light background color
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  logo: {
    width: 40,
    height: 40,
    marginRight: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'YourCustomFont', // Replace with your font name
    color: '#333', // Changed to a dark text color
    marginBottom: 16,
  },
  menuItemContainer: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  menuItem: {
    fontSize: 18,
    fontFamily: 'YourCustomFont', // Replace with your font name
    color: '#333', // Changed to a dark text color
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 16,
  },
});

export default MenuScreen;

