import React, { useState } from 'react';
import { View } from 'react-native';
import LoginScreen from './LoginScreen';
import HomeScreen from './HomeScreen';
import MenuScreen from './MenuScreen';
import EnterMenuScreen from './EnterMenuScreen';
import MealSelectionScreen from './MealSelectionScreen';
import CheckoutScreen from './CheckoutScreen';
import RatingScreen from './RatingScreen';
import CartScreen from './CartScreen';
import ProfileScreen from './ProfileScreen';
import VeganScreen from './veganScreen'; // Corrected import
import NonVeganScreen from './NonVeganScreen';

const App = () => {
  const [currentScreen, setCurrentScreen] = useState('Login');
  const [menu, setMenu] = useState([
    { id: 1, name: 'Burger', price: 120.99, vegan: false, image: 'https://cmx.weightwatchers.com/assets-proxy/weight-watchers/image/upload/v1594406683/visitor-site/prod/ca/burgers_mobile_my18jv' },
    { id: 2, name: 'Burrito', price: 155.99, vegan: false, image: 'https://www.isleofwightmeat.co.uk/wp-content/uploads/2020/03/shutterstock_1349138753-scaled.jpg' },
    { id: 3, name: 'Non Vegan Share Meal', price: 500.99, vegan: false, image: 'https://assets.cntraveller.in/photos/60b9f9405b07c77d362e4778/master/pass/Street-food-non-veg.jpg.jpg' },
    { id: 4, name: 'Pizza', price: 149.99, vegan: false, image: 'https://assets.teenvogue.com/photos/5ab665d06d36ed4396878433/master/pass/GettyImages-519526540.jpg' },
    { id: 5, name: 'Vegan Salad', price: 90.99, vegan: true, image: 'https://simple-veganista.com/wp-content/uploads/2019/07/vegan-cobb-salad_.jpg' },
    { id: 6, name: 'Vegan Burger', price: 129.99, vegan: true, image: 'https://bing.com/th?id=OSK.cf9e34d422fc66b8b843f45a8cfa5577' },
    { id: 7, name: 'Vegan Burrito', price: 159.99, vegan: true, image: 'https://bing.com/th?id=OSK.dc66d76c516e613084a9334d9d914978' },
    { id: 8, name: 'Vegan Share Meal', price: 400.99, vegan: true, image: 'https://thegreenloot.com/wp-content/uploads/2018/05/vegan-meal-prep-weight-loss-1024x1024.jpg' },
    { id: 9, name: 'Vegan Pizza', price: 149.99, vegan: true, image: 'https://bing.com/th?id=OSK.fc0caf96d439a518133cde1caa7772ad' },
  ]);
  const [selectedItems, setSelectedItems] = useState([]);

  const handleNavigation = (screen, params) => {
    setCurrentScreen(screen);
  };

  const handleMenuUpdate = (newMenu) => {
    setMenu(newMenu);
  };

  const handleItemSelection = (item) => {
    setSelectedItems((prevItems) => {
      if (prevItems.some((selectedItem) => selectedItem.id === item.id)) {
        return prevItems.filter((selectedItem) => selectedItem.id !== item.id);
      } else {
        return [...prevItems, item];
      }
    });
  };

  return (
    <View style={{ flex: 1 }}>
      {currentScreen === 'Login' && <LoginScreen onNavigate={handleNavigation} />}
      {currentScreen === 'Home' && <HomeScreen onNavigate={handleNavigation} />}
      {currentScreen === 'Menu' && <MenuScreen onNavigate={handleNavigation} menu={menu} />}
      {currentScreen === 'EnterMenu' && <EnterMenuScreen onNavigate={handleNavigation} onMenuUpdate={handleMenuUpdate} />}
      {currentScreen === 'MealSelection' && <MealSelectionScreen onNavigate={handleNavigation} />}
      {currentScreen === 'Checkout' && <CheckoutScreen onNavigate={handleNavigation} selectedItems={selectedItems} />}
      {currentScreen === 'Rating' && <RatingScreen onNavigate={handleNavigation} />}
      {currentScreen === 'Cart' && <CartScreen onNavigate={handleNavigation} selectedItems={selectedItems} />}
      {currentScreen === 'Profile' && <ProfileScreen onNavigate={handleNavigation} />}
      {currentScreen === 'Vegan' && <VeganScreen onNavigate={handleNavigation} menu={menu} onSelectItem={handleItemSelection} />}
      {currentScreen === 'NonVegan' && <NonVeganScreen onNavigate={handleNavigation} menu={menu} onSelectItem={handleItemSelection} />}
    </View>
  );
};

export default App;
