// screens/HomeScreen.js
import React, { useEffect } from 'react';
import { View, Text, Button, StyleSheet, ImageBackground, Animated } from 'react-native';
import colors from './coloures/colors'; 

const HomeScreen = ({ onNavigate }) => {
  const fadeAnim = new Animated.Value(3); 

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 3,
      duration: 2000,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  return (
    <Animated.View style={{ ...styles.container, opacity: fadeAnim }}>
      <ImageBackground source={require('./assets/christofell.jpg')} style={styles.backgroundImage}>
        <View style={styles.overlay}>
          <Text style={styles.title}>Welcome to Chef Christofell's App</Text>
          <Text style={styles.slogan}>Savor the Flavor, Share the Love!</Text>
          <View style={styles.buttonContainer}>
            <Button title="Enter Menu(chef)" onPress={() => onNavigate('EnterMenu')} color={colors.primary} />
            <Button title="View Profile" onPress={() => onNavigate('Profile')} color={colors.primary} />
            <Button title="View Menu(customer)" onPress={() => onNavigate('Menu')} color={colors.primary} />
          </View>
        </View>
      </ImageBackground>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    fontFamily: 'serif',
    color: 'white',
    marginBottom: 10,
    textAlign: 'center',
  },
  slogan: {
    fontSize: 18,
    fontFamily: 'sans-serif',
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
  },
  buttonContainer: {
    width: '80%',
    marginTop: 20,
  },
  ctaButton: {
    backgroundColor: colors.accent,
    padding: 10,
    borderRadius: 5,
  },
});

export default HomeScreen;
