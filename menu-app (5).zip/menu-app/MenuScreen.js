import React from 'react';
import { View, Text, Button, FlatList, Image, StyleSheet } from 'react-native';
import colors from './coloures/colors'; 

const MenuScreen = ({ onNavigate, menu }) => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={require('./assets/christofell.jpg')} style={styles.logo} />
        <Text style={styles.title}>Today's Menu</Text>
      </View>
      <Text style={styles.itemCount}>Number of items: {menu.length}</Text>
      <FlatList
        data={menu}
        renderItem={({ item }) => (
          <View style={styles.menuItemContainer}>
            <Text style={styles.menuItem}>{item.course} - {item.type}: {item.name} - R{item.price}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id.toString()}
      />
      <View style={styles.buttonContainer}>
        <Button title="Next" onPress={() => onNavigate('Checkout', { selectedMeal: menu })} color={colors.primary} />
        <Button title="Back" onPress={() => onNavigate('EnterMenu')} color={colors.primary} />
        <Button title="Vegan" onPress={() => onNavigate('Vegan')} color={colors.primary} />
        <Button title="Non-Vegan" onPress={() => onNavigate('NonVegan')} color={colors.primary} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f9f9f9', 
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  logo: {
    width: 40,
    height: 40,
    marginRight: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'YourCustomFont',
    color: '#333', // 
    marginBottom: 16,
  },
  itemCount: {
    fontSize: 18,
    fontFamily: 'YourCustomFont', 
    color: '#333',
    marginBottom: 16,
  },
  menuItemContainer: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  menuItem: {
    fontSize: 18,
    fontFamily: 'YourCustomFont',
    color: '#333',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 16,
  },
});

export default MenuScreen;
