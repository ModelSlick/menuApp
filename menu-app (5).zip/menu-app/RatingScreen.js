// screens/FeedbackScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, Button, TouchableOpacity } from 'react-native';
import colors from './coloures/colors'; // Corrected path

const RatingScreen = ({ onNavigate }) => {
  const [rating, setRating] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const handleRating = (value) => {
    setRating(value);
  };

  const handleSubmit = () => {
    setSubmitted(true);
  };

  return (
    <View style={styles.container}>
      {!submitted ? (
        <>
          <Text style={styles.title}>Rate Your Experience</Text>
          <View style={styles.starsContainer}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity key={star} onPress={() => handleRating(star)}>
                <Text style={styles.star}>{star <= rating ? '★' : '☆'}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Button title="Submit" onPress={handleSubmit} color={colors.primary} />
        </>
      ) : (
        <>
          <Text style={styles.title}>Feedback</Text>
          <Text>Thank you for dining with private chef Christofell</Text>
          <Button title="Back to Home" onPress={() => onNavigate('Home')} color={colors.primary} />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
    color: colors.text,
  },
  starsContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  star: {
    fontSize: 32,
    marginHorizontal: 4,
    color: colors.primary,
  },
});

export default RatingScreen;

